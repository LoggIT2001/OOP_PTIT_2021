/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package J07027;

/**
 *
 * @author LONGDT
 */
public class BaiTap {
    private int stt;
    private String bt;

    public BaiTap() {
    }

    public BaiTap(int stt, String bt) {
        this.stt = stt;
        this.bt = bt;
    }

    public int getStt() {
        return stt;
    }

    public String getBt() {
        return bt;
    }
    
}
