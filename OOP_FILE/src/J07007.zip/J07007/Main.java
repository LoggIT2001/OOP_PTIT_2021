/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package J07007;

import java.util.*;
import java.io.*;

/**
 *
 * @author LONGDT
 */
public class Main {
    public static void main(String[] args) throws IOException {
        WordSet ws = new WordSet("VANBAN.txt");
        System.out.println(ws);
    }
}
