// danh sach doanh nghiep nhan sinh vien thuc tap 2
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package J05029;

/**
 *
 * @author LONGDT
 */
public class Main {
    public static void main(String[] args) {
        DSDoanhNghiep ds = new DSDoanhNghiep();
        ds.nhap();
    }
}
